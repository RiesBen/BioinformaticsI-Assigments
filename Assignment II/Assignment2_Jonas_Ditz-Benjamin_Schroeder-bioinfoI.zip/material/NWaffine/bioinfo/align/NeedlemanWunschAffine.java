package exampleCode.bioinfo.align;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Stack;

/**
 * compute a global alignment using the Needleman Wunsch algorithm
 */
public class NeedlemanWunschAffine extends NeedlemanWunschAffineBase {

    /**
     * compute a global alignment using the Needleman Wunsch algorithm
     */
    public void compute() 
    {
    	// please implement the NW algorithm with affine gap penalties 
    	//TODO: look at the methods of the base class
    	
    	//TODO: Remember the three steps in each dynamic programming algorithm
    	//TODO: Think of a clever way to store your data
    	
    	//TODO make use of the class ScoreMatrix to also allow the user 
    	//to input a scoring matrix instead of simple match / mismatch scores
    }
}
